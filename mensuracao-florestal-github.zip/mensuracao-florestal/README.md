# Mensuração Florestal — Desafios de dados

Repositório do grupo com os desafios da disciplina de Mensuração Florestal.

**Integrantes:** [Nome 1], [Nome 2], [Nome 3]

| Pasta | Desafio | Status |
|---|---|---|
| [`desafio-08-validacao-sitio/`](desafio-08-validacao-sitio/) | Classificação de sítio: validação e preparação da base para o modelo de Clutter | Concluído |
| `desafio-09-modelo-clutter/` | Modelo de crescimento e produção de Clutter | Em andamento |

Cada pasta tem seu próprio README, com instruções de execução, e um relatório curto (`relatorio.md`).

## Requisitos

- R ≥ 4.1
- Pacotes: `readxl`, `ggplot2`

```r
install.packages(c("readxl", "ggplot2"))
```
